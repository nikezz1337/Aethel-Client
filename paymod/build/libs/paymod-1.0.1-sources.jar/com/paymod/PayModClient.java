package com.paymod;

import com.paymod.config.ModConfig;
import com.paymod.gui.ConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

public class PayModClient implements ClientModInitializer {
    private static final class_304.class_11900 PAYMOD_CATEGORY = class_304.class_11900.method_74698(
        class_2960.method_60655("paymod", "main")
    );
    private static class_304 toggleKey;
    private static class_304 configKey;
    private static boolean enabled = false;
    private static long lastCheckTime = 0;
    private static boolean waitingForMoney = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(
            new class_304("key.paymod.toggle", class_3675.class_307.field_1668, 80, PAYMOD_CATEGORY)
        );
        configKey = KeyBindingHelper.registerKeyBinding(
            new class_304("key.paymod.config", class_3675.class_307.field_1668, 79, PAYMOD_CATEGORY)
        );

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        ClientReceiveMessageEvents.GAME.register(this::onGameMessage);
    }

    private void onTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (toggleKey.method_1436()) {
            enabled = !enabled;
            client.field_1724.method_7353(
                class_2561.method_43470(enabled ? "\u00a7a\u0412\u043a\u043b\u044e\u0447\u0435\u043d" : "\u00a7c\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d"), false
            );
        }

        if (configKey.method_1436()) {
            client.method_1507(new ConfigScreen(null));
        }

        if (enabled && !waitingForMoney) {
            long now = System.currentTimeMillis();
            if (now - lastCheckTime >= 60000) {
                lastCheckTime = now;
                if (client.field_1724.field_3944 != null) {
                    client.field_1724.field_3944.method_45730("money");
                    waitingForMoney = true;
                }
            }
        }
    }

    private void onGameMessage(class_2561 message, boolean overlay) {
        if (!waitingForMoney) return;
        processMoneyResponse(message);
    }

    private void processMoneyResponse(class_2561 message) {
        waitingForMoney = false;
        String text = message.getString();
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        double balance = extractBalance(text);
        if (balance <= 0) return;

        double keepAmount = ModConfig.getKeepAmount();

        if (balance > keepAmount) {
            double excess = balance - keepAmount;
            String target = ModConfig.getTargetPlayer();
            String amount = formatAmount(excess);

            mc.field_1724.field_3944.method_45730("pay " + target + " " + amount);
            mc.field_1724.method_7353(
                class_2561.method_43470("\u00a7a\u041f\u0435\u0440\u0435\u0432\u0435\u0434\u0435\u043d\u043e \u00a7f" + amount + " \u00a7a\u0438\u0433\u0440\u043e\u043a\u0443 \u00a7f" + target + " \u00a7a(\u0411\u0430\u043b\u0430\u043d\u0441: \u00a7f" + formatAmount(balance) + "\u00a7a)"), false
            );
        } else {
            mc.field_1724.method_7353(
                class_2561.method_43470("\u00a7e\u0411\u0430\u043b\u0430\u043d\u0441: \u00a7f" + formatAmount(balance) + " \u00a7e(\u041d\u0443\u0436\u043d\u043e: \u00a7f" + formatAmount(keepAmount) + "\u00a7e)"), false
            );
        }
    }

    private double extractBalance(String message) {
        String cleaned = message.replaceAll("[,\\s]", "");
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\d+\\.?\\d*");
        java.util.regex.Matcher matcher = pattern.matcher(cleaned);
        double max = 0;
        while (matcher.find()) {
            try {
                double val = Double.parseDouble(matcher.group());
                if (val > max) max = val;
            } catch (NumberFormatException ignored) {}
        }
        return max;
    }

    private String formatAmount(double amount) {
        if (amount == (long) amount) {
            return String.format("%.0f", amount);
        }
        return String.format("%.2f", amount);
    }
}
