package com.paymod.gui;

import com.paymod.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 keepAmountField;
    private class_342 targetPlayerField;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("PayMod"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;

        keepAmountField = new class_342(this.field_22793, centerX - 75, 50, 150, 20, class_2561.method_43470(""));
        keepAmountField.method_1852(String.valueOf((long) ModConfig.getKeepAmount()));
        keepAmountField.method_1863(s -> {
            try {
                double val = Double.parseDouble(s);
                ModConfig.setKeepAmount(val);
                ModConfig.save();
            } catch (NumberFormatException ignored) {}
        });
        this.method_37063(keepAmountField);

        targetPlayerField = new class_342(this.field_22793, centerX - 75, 95, 150, 20, class_2561.method_43470(""));
        targetPlayerField.method_1852(ModConfig.getTargetPlayer());
        targetPlayerField.method_1863(s -> {
            ModConfig.setTargetPlayer(s);
            ModConfig.save();
        });
        this.method_37063(targetPlayerField);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Сохранить"), button -> {
            this.method_25419();
        }).method_46434(centerX - 50, 135, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51433(this.field_22793, "PayMod - Настройки", this.field_22789 / 2 - 55, 15, 0xFFFFFF, false);
        context.method_51433(this.field_22793, "Сохранять сумму:", this.field_22789 / 2 - 75, 38, 0xAAAAAA, false);
        context.method_51433(this.field_22793, "Игрок для перевода:", this.field_22789 / 2 - 75, 83, 0xAAAAAA, false);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        ModConfig.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}
